# MediaHub AI

A premium, futuristic web app combining a **license-compliant media downloader**
with a **full conversational AI assistant** ("Nova"), built on Next.js 14
(App Router), TypeScript, Prisma, NextAuth, and Tailwind.

---

## ⚠️ Read this first: the media downloader's scope

This project deliberately does **not** include a generic YouTube / Instagram /
TikTok / etc. ripper. Extracting media streams from those platforms almost
always violates the platform's Terms of Service and, for anything the
requester doesn't own the rights to, copyright law — regardless of how the
UI around it is framed. Building that is out of scope on purpose, per the
"only legally permitted downloads" requirement in the original spec.

Instead, the downloader is built around a **pluggable provider system**
(`src/lib/mediaProviders/`). Each provider declares which URLs it can
handle and returns real, licensed, direct-download links. The one shipped
example, `archiveOrgProvider.ts`, surfaces direct file URLs for
public-domain / openly-licensed items via the **Internet Archive's public
metadata API** — a genuine, legal example of "supported platform."

**To add more legal sources**, write a new provider that calls an official
API you're authorized to use — e.g. a creator's own CMS export API, a stock
media library you hold a license for, your own S3 bucket of owned assets,
or a podcast host's public RSS enclosure URLs — and register it in
`src/lib/mediaProviders/registry.ts`. Never scrape or reverse-engineer a
platform's private streaming endpoints to bypass its ToS; that's a legal
and account-suspension risk for whoever operates this app, not just a
policy nicety.

---

## Features implemented

1. **Media downloader** — paste-a-link → analyze → format/quality picker →
   progress bar → download, with error handling and license-compliant
   provider architecture.
2. **AI Assistant ("Nova")** — full ChatGPT-style interface, server-side
   calls to Claude, multi-turn context via stored conversation history,
   suggested prompts, typing indicator.
3. **AI intro animation** — cinematic one-time intro (stored in
   `localStorage`) before the chat unlocks.
4. **Website intro animation** — logo reveal + particles on first visit per
   session (`sessionStorage`), skippable, auto-dismisses.
5. **Authentication** — email/password signup & login via NextAuth
   credentials provider, bcrypt password hashing (cost 12), JWT sessions.
6. **Profile management** — change username, display name, bio, avatar URL.
7. **History** — every download and AI chat is logged per-user; search,
   filter by type, delete individual items, clear all.
8. **Premium UI** — glassmorphism cards, gradient accents, dark/light theme
   with persistence, Framer Motion micro-interactions, responsive nav,
   loading skeletons, toast notifications, empty states.
9. **Security** — bcrypt hashing, Zod input validation on every route,
   per-route in-memory rate limiting, same-origin CSRF check middleware,
   ownership checks before any mutation/deletion, security headers
   (CSP, X-Frame-Options, etc.) in `next.config.js`, no secrets in
   client bundles.
10. **Scalability groundwork** — stateless API routes, no server-side
    proxying/storage of third-party media (downloads point straight at the
    provider's own direct URL, so bandwidth doesn't bottleneck through this
    app), a rate limiter designed to be swapped for Redis with a one-file
    change, Prisma schema portable from SQLite (dev) to Postgres (prod).

---

## Getting started

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# then edit .env:
#   - NEXTAUTH_SECRET: generate with `openssl rand -base64 32`
#   - ANTHROPIC_API_KEY: your Anthropic API key (server-side only)

# 3. Set up the database (SQLite by default for local dev)
npx prisma generate
npx prisma migrate dev --name init

# 4. Run the dev server
npm run dev
```

Visit `http://localhost:3000`.

### Try the downloader
Paste an Internet Archive item URL, e.g.
`https://archive.org/details/BigBuckBunny_328` — it's a real openly-licensed
film hosted by the Archive, good for testing the full analyze → pick
format → download flow end to end.

### Try the AI assistant
Go to `/ai`. Requires `ANTHROPIC_API_KEY` to be set — without it, the chat
API will return a clear error rather than silently failing.

---

## Moving to production

- **Database**: switch `prisma/schema.prisma`'s datasource `provider` to
  `"postgresql"` and point `DATABASE_URL` at a managed Postgres instance
  (Neon, Supabase, RDS, etc.) — SQLite doesn't handle concurrent writers
  well under real multi-user load.
- **Rate limiting**: replace the in-memory `Map` in `src/lib/rateLimit.ts`
  with a shared store (Redis / Upstash) so limits are enforced consistently
  across multiple server instances. The function signature is kept small
  specifically so this is a one-file swap.
- **Sessions**: JWT sessions (current setup) scale horizontally without a
  shared session store; if you need instant server-side revocation, switch
  the NextAuth `session.strategy` to `"database"`.
- **Secrets**: keep `ANTHROPIC_API_KEY` and `NEXTAUTH_SECRET` in your
  hosting platform's secret manager — never commit `.env`.
- **Asset delivery**: put this behind a CDN/edge network for static assets
  and enable HTTP/2+ compression at the proxy layer.

---

## Project structure

```
src/
  app/
    page.tsx                  # Home: hero + downloader
    ai/page.tsx                # AI assistant page
    dashboard/page.tsx         # Logged-in overview
    history/page.tsx           # History browser
    profile/page.tsx           # Account settings
    login/, signup/            # Auth pages
    api/
      auth/[...nextauth]/      # NextAuth handler
      auth/signup/             # Registration
      media/analyze/           # URL → available formats
      media/download/          # Finalize a download job
      ai/chat/                 # Claude-backed chat, context-aware
      history/                 # List / clear / delete
      profile/                 # Get / update profile
    globals.css                 # Theme tokens, glassmorphism utilities
    layout.tsx                  # Root layout + providers
  components/                   # UI building blocks (see file headers)
  lib/
    mediaProviders/             # Pluggable, license-scoped download sources
    auth.ts, prisma.ts, rateLimit.ts, validation.ts, anthropic.ts, utils.ts
  middleware.ts                 # Same-origin CSRF check
prisma/schema.prisma
```

---

## Known limitations of this scaffold

- The download-provider list ships with exactly one real source
  (Internet Archive). That's intentional, not a bug — see the notice at
  the top of this file.
- The rate limiter and session store are single-instance by default; see
  "Moving to production" above before deploying behind multiple server
  processes.
- No automated test suite is included yet — add Vitest/Playwright as a
  next step for a real production rollout.
- This code has not been run through `npm install` / a live build in the
  environment it was authored in (no network access there), so do a local
  `npm install && npm run build` pass and fix any dependency-version drift
  before deploying.
