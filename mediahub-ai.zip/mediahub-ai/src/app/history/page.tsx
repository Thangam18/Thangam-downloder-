"use client";

import { useSession } from "next-auth/react";
import Link from "next/link";
import { HistoryList } from "@/components/HistoryList";
import { GlassCard } from "@/components/GlassCard";

export default function HistoryPage() {
  const { status } = useSession();

  if (status === "loading") return null;

  if (status === "unauthenticated") {
    return (
      <div className="mx-auto max-w-md px-4 py-24">
        <GlassCard className="p-8 text-center">
          <h2 className="font-display font-semibold text-lg mb-2">Sign in to view history</h2>
          <p className="text-sm text-muted-foreground mb-5">
            Your download and AI chat history is saved to your account.
          </p>
          <Link
            href="/login"
            className="inline-block px-5 py-2 rounded-lg bg-gradient-to-r from-primary to-accent text-white text-sm font-semibold"
          >
            Log in
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <section className="mx-auto max-w-3xl px-4 sm:px-6 py-10">
      <h1 className="text-2xl font-display font-bold mb-1">Your History</h1>
      <p className="text-sm text-muted-foreground mb-6">Downloads, AI conversations, and account activity.</p>
      <HistoryList />
    </section>
  );
}
