"use client";

import { motion } from "framer-motion";
import { Zap, ShieldCheck, Gauge, Sparkles } from "lucide-react";
import { IntroAnimation } from "@/components/IntroAnimation";
import { DownloaderPanel } from "@/components/DownloaderPanel";
import { GlassCard } from "@/components/GlassCard";
import Link from "next/link";

const FEATURES = [
  { icon: Zap, title: "Fast processing", desc: "Optimized analysis pipeline with real-time progress." },
  { icon: ShieldCheck, title: "License-compliant", desc: "Only surfaces downloads from sources you're legally permitted to use." },
  { icon: Gauge, title: "Built to scale", desc: "Stateless media handling keeps things smooth under concurrent load." }
];

export default function HomePage() {
  return (
    <>
      <IntroAnimation />

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-grid-glow pointer-events-none" />
        <div className="relative mx-auto max-w-6xl px-4 sm:px-6 pt-20 pb-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs font-medium text-muted-foreground mb-6"
          >
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Premium media downloads, done the legal way
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl sm:text-6xl font-display font-bold tracking-tight"
          >
            Download media.
            <br />
            <span className="text-gradient">Chat with an AI that gets it.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-5 max-w-2xl mx-auto text-muted-foreground"
          >
            Paste a link, pick your format and quality, and download in seconds — from
            sources that respect copyright. Then jump into Nova, your built-in AI
            assistant, for anything else on your mind.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-10"
          >
            <DownloaderPanel />
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="mt-6 text-xs text-muted-foreground"
          >
            Currently supported: Internet Archive (public domain / openly licensed media).{" "}
            <Link href="/ai" className="text-primary hover:underline">
              Or try the AI Assistant →
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-24">
        <div className="grid sm:grid-cols-3 gap-4">
          {FEATURES.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <GlassCard className="p-6 h-full hover:-translate-y-1 transition-transform duration-300">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4">
                  <f.icon className="h-5 w-5 text-white" />
                </div>
                <h3 className="font-semibold mb-1.5">{f.title}</h3>
                <p className="text-sm text-muted-foreground">{f.desc}</p>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </section>
    </>
  );
}
