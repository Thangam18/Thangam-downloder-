import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { chatMessageSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rateLimit";
import { generateChatReply, ChatTurn } from "@/lib/anthropic";

const MAX_HISTORY_TURNS = 20;

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;

  // Logged-out visitors can still try the assistant, just at a tighter limit.
  const limitKey = userId ?? `ip:${req.headers.get("x-forwarded-for") ?? "unknown"}`;
  const limited = rateLimit(`chat:${limitKey}`, userId ? 40 : 10, 60_000);
  if (!limited.success) {
    return NextResponse.json({ error: "You're sending messages too quickly. Take a short break." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = chatMessageSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid message" }, { status: 400 });
  }

  try {
    let conversationId = parsed.data.conversationId;
    let history: ChatTurn[] = [];

    if (userId) {
      let conversation = conversationId
        ? await prisma.conversation.findFirst({ where: { id: conversationId, userId } })
        : null;

      if (!conversation) {
        conversation = await prisma.conversation.create({
          data: { userId, title: parsed.data.message.slice(0, 60) }
        });
      }
      conversationId = conversation.id;

      const priorMessages = await prisma.message.findMany({
        where: { conversationId },
        orderBy: { createdAt: "asc" },
        take: MAX_HISTORY_TURNS
      });

      history = priorMessages.map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

      await prisma.message.create({
        data: { conversationId, role: "user", content: parsed.data.message }
      });
    }

    history.push({ role: "user", content: parsed.data.message });

    const reply = await generateChatReply(history);

    if (userId && conversationId) {
      await prisma.message.create({
        data: { conversationId, role: "assistant", content: reply }
      });
      await prisma.historyItem.create({
        data: {
          userId,
          type: "ai_chat",
          label: `Asked: ${parsed.data.message.slice(0, 80)}`,
          metadata: JSON.stringify({ conversationId })
        }
      });
    }

    return NextResponse.json({ reply, conversationId });
  } catch (err) {
    console.error("[ai/chat]", err);
    return NextResponse.json(
      { error: "The assistant is temporarily unavailable. Please try again." },
      { status: 502 }
    );
  }
}
