import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in to view your history." }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();
  const type = searchParams.get("type")?.trim();

  const items = await prisma.historyItem.findMany({
    where: {
      userId,
      ...(type ? { type } : {}),
      ...(q ? { label: { contains: q } } : {})
    },
    orderBy: { createdAt: "desc" },
    take: 200
  });

  return NextResponse.json({ items });
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;
  if (!userId) {
    return NextResponse.json({ error: "Sign in required." }, { status: 401 });
  }

  // Bulk clear-all (no body needed). Individual deletes use /api/history/[id].
  await prisma.historyItem.deleteMany({ where: { userId } });
  return NextResponse.json({ success: true });
}
