import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { mediaDownloadSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rateLimit";

// This endpoint finalizes a previously-analyzed job: it records the
// chosen format/quality and marks the job COMPLETED. The actual file
// bytes are served directly from the provider's own direct URL
// (returned during /analyze) — this backend never proxies or stores
// third-party media itself, which keeps storage/bandwidth costs flat
// regardless of concurrent users.
export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  const limited = rateLimit(`download:${ip}`, 20, 60_000);
  if (!limited.success) {
    return NextResponse.json({ error: "Too many requests. Please slow down." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = mediaDownloadSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;

  const job = await prisma.mediaDownload.findUnique({ where: { id: parsed.data.jobId } });
  if (!job) {
    return NextResponse.json({ error: "Download job not found." }, { status: 404 });
  }

  const updated = await prisma.mediaDownload.update({
    where: { id: job.id },
    data: {
      format: parsed.data.format,
      quality: parsed.data.quality,
      status: "COMPLETED"
    }
  });

  if (userId) {
    await prisma.historyItem.create({
      data: {
        userId,
        type: "download",
        label: `Downloaded: ${job.title ?? job.sourceUrl} (${parsed.data.format}, ${parsed.data.quality})`,
        metadata: JSON.stringify({ jobId: job.id })
      }
    });
  }

  return NextResponse.json({ success: true, job: updated });
}
