import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { mediaAnalyzeSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rateLimit";
import { findProvider } from "@/lib/mediaProviders/registry";
import { UnsupportedMediaError } from "@/lib/mediaProviders/types";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  const limited = rateLimit(`analyze:${ip}`, 15, 60_000);
  if (!limited.success) {
    return NextResponse.json({ error: "Too many requests. Please slow down." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = mediaAnalyzeSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid URL" }, { status: 400 });
  }

  const session = await getServerSession(authOptions);
  const userId = (session?.user as any)?.id as string | undefined;

  try {
    const provider = findProvider(parsed.data.url);
    const result = await provider.analyze(parsed.data.url);

    const job = await prisma.mediaDownload.create({
      data: {
        userId: userId ?? null,
        sourceUrl: parsed.data.url,
        provider: result.provider,
        title: result.title,
        status: "READY"
      }
    });

    if (userId) {
      await prisma.historyItem.create({
        data: {
          userId,
          type: "download",
          label: `Analyzed: ${result.title}`,
          metadata: JSON.stringify({ jobId: job.id, url: parsed.data.url })
        }
      });
    }

    return NextResponse.json({ jobId: job.id, ...result });
  } catch (err) {
    if (err instanceof UnsupportedMediaError) {
      return NextResponse.json({ error: err.message }, { status: 422 });
    }
    console.error("[media/analyze]", err);
    return NextResponse.json({ error: "Something went wrong analyzing that link." }, { status: 500 });
  }
}
