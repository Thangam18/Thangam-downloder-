import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { signupSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rateLimit";

export async function POST(req: NextRequest) {
  // Rate limit by IP to slow down automated account creation abuse.
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  const limited = rateLimit(`signup:${ip}`, 5, 60_000);
  if (!limited.success) {
    return NextResponse.json({ error: "Too many attempts. Try again shortly." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = signupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const { email, username, password } = parsed.data;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] }
  });
  if (existing) {
    // Deliberately vague to avoid leaking which field collided.
    return NextResponse.json({ error: "An account with these details already exists." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const user = await prisma.user.create({
    data: { email, username, passwordHash, displayName: username }
  });

  await prisma.historyItem.create({
    data: { userId: user.id, type: "account", label: "Account created" }
  });

  return NextResponse.json({ success: true }, { status: 201 });
}
