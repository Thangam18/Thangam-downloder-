import type { Metadata } from "next";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { AuthSessionProvider } from "@/components/AuthSessionProvider";
import { ToastProvider } from "@/components/ToastProvider";
import { Navbar } from "@/components/Navbar";

export const metadata: Metadata = {
  title: "MediaHub AI — Premium Media & AI Platform",
  description:
    "A futuristic, premium platform combining a license-compliant media downloader with a powerful conversational AI assistant.",
  icons: { icon: "/favicon.svg" }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className="min-h-screen font-sans antialiased">
        <AuthSessionProvider>
          <ThemeProvider>
            <ToastProvider>
              <Navbar />
              <main className="min-h-screen pt-16">{children}</main>
            </ToastProvider>
          </ThemeProvider>
        </AuthSessionProvider>
      </body>
    </html>
  );
}
