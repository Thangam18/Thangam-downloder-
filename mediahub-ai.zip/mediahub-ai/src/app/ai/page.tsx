"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { AIIntroAnimation } from "@/components/AIIntroAnimation";
import { ChatInterface } from "@/components/ChatInterface";

export default function AIPage() {
  const [ready, setReady] = useState(false);

  return (
    <>
      <AIIntroAnimation onDone={() => setReady(true)} />

      {ready && (
        <section className="mx-auto max-w-4xl px-4 sm:px-6 py-10">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 text-center"
          >
            <h1 className="text-3xl font-display font-bold">
              <span className="text-gradient">Nova</span> AI Assistant
            </h1>
            <p className="text-sm text-muted-foreground mt-1.5">
              Ask questions, get things explained, brainstorm — Nova remembers your
              conversation as you go.
            </p>
          </motion.div>

          <ChatInterface />
        </section>
      )}
    </>
  );
}
