"use client";

import { useSession } from "next-auth/react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Download, Sparkles, History, Settings } from "lucide-react";
import { GlassCard } from "@/components/GlassCard";

const shortcuts = [
  { href: "/", icon: Download, title: "New Download", desc: "Paste a link and start downloading" },
  { href: "/ai", icon: Sparkles, title: "Ask Nova", desc: "Open the AI assistant" },
  { href: "/history", icon: History, title: "View History", desc: "See your past activity" },
  { href: "/profile", icon: Settings, title: "Account Settings", desc: "Manage your profile" }
];

export default function DashboardPage() {
  const { data: session, status } = useSession();

  if (status === "loading") return null;

  if (status === "unauthenticated") {
    return (
      <div className="mx-auto max-w-md px-4 py-24">
        <GlassCard className="p-8 text-center">
          <h2 className="font-display font-semibold text-lg mb-2">Sign in to see your dashboard</h2>
          <Link
            href="/login"
            className="inline-block mt-3 px-5 py-2 rounded-lg bg-gradient-to-r from-primary to-accent text-white text-sm font-semibold"
          >
            Log in
          </Link>
        </GlassCard>
      </div>
    );
  }

  const name = (session?.user as any)?.username ?? session?.user?.name ?? "there";

  return (
    <section className="mx-auto max-w-5xl px-4 sm:px-6 py-10">
      <h1 className="text-2xl font-display font-bold mb-1">Welcome back, {name} 👋</h1>
      <p className="text-sm text-muted-foreground mb-8">Here's a quick way back into everything.</p>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {shortcuts.map((s, i) => (
          <motion.div
            key={s.href}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06 }}
          >
            <Link href={s.href}>
              <GlassCard className="p-5 h-full hover:-translate-y-1 hover:shadow-2xl transition-all duration-300">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-3">
                  <s.icon className="h-5 w-5 text-white" />
                </div>
                <p className="font-semibold text-sm">{s.title}</p>
                <p className="text-xs text-muted-foreground mt-1">{s.desc}</p>
              </GlassCard>
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
