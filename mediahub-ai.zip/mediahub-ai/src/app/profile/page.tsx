"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import Link from "next/link";
import toast from "react-hot-toast";
import { motion } from "framer-motion";
import { User, Save } from "lucide-react";
import { GlassCard } from "@/components/GlassCard";
import { Skeleton } from "@/components/LoadingSkeleton";

interface Profile {
  username: string;
  displayName: string | null;
  bio: string | null;
  avatarUrl: string | null;
  email: string;
}

export default function ProfilePage() {
  const { status } = useSession();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (status !== "authenticated") return;
    fetch("/api/profile")
      .then((r) => r.json())
      .then((d) => setProfile(d.user));
  }, [status]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    try {
      const res = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: profile.username,
          displayName: profile.displayName ?? undefined,
          bio: profile.bio ?? undefined,
          avatarUrl: profile.avatarUrl ?? undefined
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Couldn't save changes.");
      toast.success("Profile updated.");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (status === "loading") return null;

  if (status === "unauthenticated") {
    return (
      <div className="mx-auto max-w-md px-4 py-24">
        <GlassCard className="p-8 text-center">
          <h2 className="font-display font-semibold text-lg mb-2">Sign in to manage your profile</h2>
          <Link
            href="/login"
            className="inline-block mt-3 px-5 py-2 rounded-lg bg-gradient-to-r from-primary to-accent text-white text-sm font-semibold"
          >
            Log in
          </Link>
        </GlassCard>
      </div>
    );
  }

  return (
    <section className="mx-auto max-w-2xl px-4 sm:px-6 py-10">
      <h1 className="text-2xl font-display font-bold mb-6">Account Settings</h1>

      {!profile ? (
        <div className="space-y-3">
          <Skeleton className="h-14 w-full" />
          <Skeleton className="h-14 w-full" />
          <Skeleton className="h-14 w-full" />
        </div>
      ) : (
        <motion.form initial={{ opacity: 0 }} animate={{ opacity: 1 }} onSubmit={save}>
          <GlassCard className="p-6 space-y-5">
            <div className="flex items-center gap-4">
              <div className="h-16 w-16 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center overflow-hidden shrink-0">
                {profile.avatarUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={profile.avatarUrl} alt="" className="h-full w-full object-cover" />
                ) : (
                  <User className="h-7 w-7 text-white" />
                )}
              </div>
              <div className="flex-1">
                <label className="block text-xs font-medium text-muted-foreground mb-1">Avatar URL</label>
                <input
                  value={profile.avatarUrl ?? ""}
                  onChange={(e) => setProfile({ ...profile, avatarUrl: e.target.value })}
                  placeholder="https://…"
                  className="w-full bg-muted rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-primary/40"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Username</label>
              <input
                value={profile.username}
                onChange={(e) => setProfile({ ...profile, username: e.target.value })}
                className="w-full bg-muted rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Display name</label>
              <input
                value={profile.displayName ?? ""}
                onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
                className="w-full bg-muted rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Bio</label>
              <textarea
                value={profile.bio ?? ""}
                onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
                rows={3}
                maxLength={280}
                className="w-full bg-muted rounded-lg px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40 resize-none"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1">Email</label>
              <input
                value={profile.email}
                disabled
                className="w-full bg-muted/50 rounded-lg px-3 py-2.5 text-sm text-muted-foreground cursor-not-allowed"
              />
            </div>

            <button
              type="submit"
              disabled={saving}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-gradient-to-r from-primary to-accent text-white text-sm font-semibold disabled:opacity-60"
            >
              <Save className="h-4 w-4" />
              {saving ? "Saving…" : "Save changes"}
            </button>
          </GlassCard>
        </motion.form>
      )}
    </section>
  );
}
