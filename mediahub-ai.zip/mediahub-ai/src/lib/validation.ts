import { z } from "zod";

export const signupSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  username: z
    .string()
    .trim()
    .min(3, "Username must be at least 3 characters")
    .max(24, "Username must be under 24 characters")
    .regex(/^[a-zA-Z0-9_]+$/, "Only letters, numbers, and underscores allowed"),
  password: z
    .string()
    .min(10, "Password must be at least 10 characters")
    .regex(/[A-Z]/, "Include at least one uppercase letter")
    .regex(/[a-z]/, "Include at least one lowercase letter")
    .regex(/[0-9]/, "Include at least one number")
});

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email(),
  password: z.string().min(1, "Password is required")
});

export const profileUpdateSchema = z.object({
  username: z
    .string()
    .trim()
    .min(3)
    .max(24)
    .regex(/^[a-zA-Z0-9_]+$/)
    .optional(),
  displayName: z.string().trim().max(60).optional(),
  bio: z.string().trim().max(280).optional(),
  avatarUrl: z.string().url().max(1024).optional(),
  theme: z.enum(["dark", "light", "system"]).optional()
});

export const mediaAnalyzeSchema = z.object({
  url: z.string().trim().url("Enter a valid URL").max(2048)
});

export const mediaDownloadSchema = z.object({
  jobId: z.string().min(1),
  format: z.string().min(1).max(16),
  quality: z.string().min(1).max(32)
});

export const chatMessageSchema = z.object({
  conversationId: z.string().optional(),
  message: z.string().trim().min(1, "Message can't be empty").max(8000)
});

export const historyDeleteSchema = z.object({
  id: z.string().min(1)
});
