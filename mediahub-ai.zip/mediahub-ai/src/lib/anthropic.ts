import Anthropic from "@anthropic-ai/sdk";

// This module only ever runs on the server (API routes). The API key
// is read from process.env and is never bundled into client JS.
let client: Anthropic | null = null;

function getClient(): Anthropic {
  if (!process.env.ANTHROPIC_API_KEY) {
    throw new Error("ANTHROPIC_API_KEY is not configured on the server.");
  }
  if (!client) {
    client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return client;
}

export interface ChatTurn {
  role: "user" | "assistant";
  content: string;
}

const SYSTEM_PROMPT = `You are Nova, the built-in AI assistant for MediaHub AI — a
premium media utility and AI platform. You are helpful, clear, and concise.
You can explain topics, help with general tasks, brainstorm, write, and hold
a natural multi-turn conversation while remembering context from earlier in
the thread. Keep answers well-formatted and avoid unnecessary filler.`;

export async function generateChatReply(history: ChatTurn[]): Promise<string> {
  const anthropic = getClient();

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 1500,
    system: SYSTEM_PROMPT,
    messages: history.map((turn) => ({ role: turn.role, content: turn.content }))
  });

  const textBlock = response.content.find((block) => block.type === "text");
  return textBlock && "text" in textBlock ? textBlock.text : "";
}
