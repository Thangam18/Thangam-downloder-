/**
 * Lightweight in-memory rate limiter, keyed per (identifier + route).
 *
 * This is fine for a single Node process. For real horizontal
 * scalability across multiple server instances, back this with a
 * shared store (Redis / Upstash) instead of process memory — the
 * interface below is intentionally kept small so that swap is a
 * one-file change (see the comment at the bottom).
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

const WINDOW_MS = Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60_000);
const MAX_REQUESTS = Number(process.env.RATE_LIMIT_MAX_REQUESTS ?? 30);

export interface RateLimitResult {
  success: boolean;
  remaining: number;
  resetAt: number;
}

export function rateLimit(key: string, max: number = MAX_REQUESTS, windowMs: number = WINDOW_MS): RateLimitResult {
  const now = Date.now();
  const existing = buckets.get(key);

  if (!existing || existing.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { success: true, remaining: max - 1, resetAt: now + windowMs };
  }

  if (existing.count >= max) {
    return { success: false, remaining: 0, resetAt: existing.resetAt };
  }

  existing.count += 1;
  return { success: true, remaining: max - existing.count, resetAt: existing.resetAt };
}

// Periodic cleanup so the map doesn't grow unbounded under load.
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}, 5 * 60_000).unref?.();

/**
 * PRODUCTION NOTE: to scale across multiple instances/pods, replace
 * the Map above with calls to Redis (INCR + EXPIRE, or a library like
 * `@upstash/ratelimit`) so all instances share one counter. The
 * function signature here can stay identical.
 */
