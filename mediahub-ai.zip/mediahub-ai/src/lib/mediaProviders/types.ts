/**
 * Pluggable media-provider architecture.
 *
 * IMPORTANT LEGAL/DESIGN NOTE
 * ----------------------------------------------------------------
 * This app does NOT include a generic YouTube/Instagram/TikTok/etc.
 * ripper. Extracting media streams from those platforms typically
 * violates their Terms of Service and, for anything the requester
 * doesn't own the rights to, copyright law — regardless of the
 * client UI wrapped around it. Building that is out of scope here
 * on purpose.
 *
 * Instead, "download support" is modeled as a registry of
 * `MediaProvider`s. Each provider is responsible for deciding
 * whether it can legally handle a given URL (`canHandle`) and, if
 * so, returning real, licensed, direct-download information
 * (`analyze`). The example provider shipped here (`archiveOrgProvider`)
 * only surfaces direct file links that the Internet Archive itself
 * serves for public-domain / openly-licensed items via its public API.
 *
 * To extend this legitimately:
 *   - Add a provider that calls an official platform API you're
 *     authorized to use (e.g. a creator's own CMS export API,
 *     a stock-media library you have a license for, your own S3
 *     bucket of owned assets, a podcast host's public RSS enclosure
 *     URLs, etc.)
 *   - Register it in `registry.ts`.
 *   - Never scrape or reverse-engineer a platform's private
 *     streaming endpoints to bypass its ToS.
 */

export interface MediaFormatOption {
  format: string; // e.g. "mp4", "mp3", "webm"
  quality: string; // e.g. "1080p", "320kbps"
  fileSizeKB: number | null;
  directUrl: string; // must be a real, legally-servable direct URL
}

export interface MediaAnalysisResult {
  provider: string;
  title: string;
  durationSeconds: number | null;
  thumbnailUrl: string | null;
  options: MediaFormatOption[];
  licenseNote: string;
}

export interface MediaProvider {
  id: string;
  label: string;
  /** Quick synchronous/cheap check on whether this provider owns the URL pattern. */
  canHandle: (url: string) => boolean;
  /** Perform the (possibly async) lookup of legally-available download options. */
  analyze: (url: string) => Promise<MediaAnalysisResult>;
}

export class UnsupportedMediaError extends Error {
  constructor(message = "This link isn't from a supported, license-compliant source yet.") {
    super(message);
    this.name = "UnsupportedMediaError";
  }
}
