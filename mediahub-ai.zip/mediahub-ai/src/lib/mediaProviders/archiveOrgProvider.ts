import { MediaAnalysisResult, MediaProvider, UnsupportedMediaError } from "./types";

/**
 * Internet Archive provider.
 *
 * archive.org hosts public-domain and openly-licensed media and
 * exposes a public metadata API specifically designed for programmatic,
 * legal access to direct file URLs. This is a genuine example of a
 * "supported platform" per the requirement to only enable legally
 * permitted downloads.
 *
 * Docs: https://archive.org/developers/metadata-schema/index.html
 */

const ARCHIVE_ITEM_REGEX = /^https?:\/\/(www\.)?archive\.org\/details\/([^/?#]+)/i;

async function fetchItemMetadata(identifier: string) {
  const res = await fetch(`https://archive.org/metadata/${encodeURIComponent(identifier)}`, {
    // Server-side fetch; short timeout via AbortController recommended in production.
    headers: { Accept: "application/json" }
  });

  if (!res.ok) {
    throw new UnsupportedMediaError("Couldn't find that Internet Archive item.");
  }

  return res.json();
}

function isMediaFile(name: string) {
  return /\.(mp4|m4v|webm|mp3|m4a|flac|ogg)$/i.test(name);
}

function guessFormat(name: string): string {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  return ext;
}

export const archiveOrgProvider: MediaProvider = {
  id: "archive_org",
  label: "Internet Archive (public domain / open license)",
  canHandle: (url: string) => ARCHIVE_ITEM_REGEX.test(url),

  analyze: async (url: string): Promise<MediaAnalysisResult> => {
    const match = url.match(ARCHIVE_ITEM_REGEX);
    if (!match) throw new UnsupportedMediaError();

    const identifier = match[2];
    const meta = await fetchItemMetadata(identifier);

    const files: any[] = Array.isArray(meta?.files) ? meta.files : [];
    const mediaFiles = files.filter((f) => typeof f?.name === "string" && isMediaFile(f.name));

    if (mediaFiles.length === 0) {
      throw new UnsupportedMediaError("No downloadable media files found on that item.");
    }

    const options = mediaFiles.slice(0, 12).map((f) => ({
      format: guessFormat(f.name),
      quality: f.height ? `${f.height}p` : f.bitrate ? `${Math.round(Number(f.bitrate) / 1000)}kbps` : "original",
      fileSizeKB: f.size ? Math.round(Number(f.size) / 1024) : null,
      directUrl: `https://archive.org/download/${identifier}/${encodeURIComponent(f.name)}`
    }));

    return {
      provider: "archive_org",
      title: meta?.metadata?.title ?? identifier,
      durationSeconds: null,
      thumbnailUrl: `https://archive.org/services/img/${identifier}`,
      options,
      licenseNote:
        meta?.metadata?.licenseurl ??
        "Public domain / openly licensed via Internet Archive. Verify individual item rights before redistribution."
    };
  }
};
