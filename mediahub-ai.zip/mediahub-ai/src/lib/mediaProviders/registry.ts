import { MediaProvider, UnsupportedMediaError } from "./types";
import { archiveOrgProvider } from "./archiveOrgProvider";

// Add additional legally-scoped providers here as you obtain the
// rights/API access to support them (see types.ts for the ground rules).
const providers: MediaProvider[] = [archiveOrgProvider];

export function findProvider(url: string): MediaProvider {
  const provider = providers.find((p) => p.canHandle(url));
  if (!provider) {
    throw new UnsupportedMediaError(
      "That link isn't from a currently supported, license-compliant source. Supported: Internet Archive (archive.org/details/...)."
    );
  }
  return provider;
}

export function listSupportedProviders() {
  return providers.map((p) => ({ id: p.id, label: p.label }));
}
