"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import { Link2, Loader2, Download, AlertTriangle, CheckCircle2, FileVideo } from "lucide-react";
import { GlassCard } from "@/components/GlassCard";
import { MediaOptionSkeleton } from "@/components/LoadingSkeleton";
import { formatBytes } from "@/lib/utils";

interface FormatOption {
  format: string;
  quality: string;
  fileSizeKB: number | null;
  directUrl: string;
}

interface AnalysisResult {
  jobId: string;
  title: string;
  thumbnailUrl: string | null;
  licenseNote: string;
  options: FormatOption[];
}

type Stage = "idle" | "analyzing" | "ready" | "error";

export function DownloaderPanel() {
  const [url, setUrl] = useState("");
  const [stage, setStage] = useState<Stage>("idle");
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [downloadingKey, setDownloadingKey] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  async function handleAnalyze(e: React.FormEvent) {
    e.preventDefault();
    if (!url.trim()) return;

    setStage("analyzing");
    setError(null);
    setResult(null);

    try {
      const res = await fetch("/api/media/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error ?? "Couldn't analyze that link.");
      }

      setResult(data);
      setStage("ready");
    } catch (err: any) {
      setError(err.message ?? "Something went wrong.");
      setStage("error");
    }
  }

  async function handleDownload(option: FormatOption) {
    if (!result) return;
    const key = `${option.format}-${option.quality}`;
    setDownloadingKey(key);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((p) => Math.min(p + Math.random() * 22, 92));
    }, 220);

    try {
      const res = await fetch("/api/media/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ jobId: result.jobId, format: option.format, quality: option.quality })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Download failed.");

      clearInterval(interval);
      setProgress(100);

      // Trigger the actual file download from the provider's direct URL.
      const anchor = document.createElement("a");
      anchor.href = option.directUrl;
      anchor.rel = "noopener noreferrer";
      anchor.target = "_blank";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();

      toast.success("Download ready!");
    } catch (err: any) {
      clearInterval(interval);
      toast.error(err.message ?? "Download failed.");
    } finally {
      setTimeout(() => {
        setDownloadingKey(null);
        setProgress(0);
      }, 900);
    }
  }

  return (
    <div className="w-full max-w-3xl mx-auto">
      <form onSubmit={handleAnalyze} className="relative">
        <GlassCard glow className="p-2 flex items-center gap-2">
          <Link2 className="ml-3 h-5 w-5 text-muted-foreground shrink-0" />
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="Paste a supported media link (e.g. https://archive.org/details/...)"
            className="flex-1 bg-transparent outline-none py-3 text-sm sm:text-base placeholder:text-muted-foreground"
            aria-label="Media URL"
          />
          <button
            type="submit"
            disabled={stage === "analyzing"}
            className="shrink-0 flex items-center gap-2 rounded-xl bg-gradient-to-r from-primary to-accent text-white px-5 py-3 text-sm font-semibold shadow-lg shadow-primary/25 hover:opacity-90 transition disabled:opacity-60"
          >
            {stage === "analyzing" ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Analyzing
              </>
            ) : (
              <>Analyze</>
            )}
          </button>
        </GlassCard>
      </form>

      <AnimatePresence mode="wait">
        {stage === "analyzing" && (
          <motion.div
            key="skeleton"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-6 space-y-3"
          >
            <MediaOptionSkeleton />
            <MediaOptionSkeleton />
          </motion.div>
        )}

        {stage === "error" && (
          <motion.div
            key="error"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-6"
          >
            <GlassCard className="p-5 flex items-start gap-3 border-red-500/40">
              <AlertTriangle className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-sm">Couldn't process that link</p>
                <p className="text-sm text-muted-foreground mt-1">{error}</p>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {stage === "ready" && result && (
          <motion.div
            key="results"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="mt-6 space-y-4"
          >
            <GlassCard className="p-4 flex items-center gap-4">
              <div className="h-16 w-24 rounded-lg overflow-hidden bg-muted flex items-center justify-center shrink-0">
                {result.thumbnailUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={result.thumbnailUrl} alt="" className="h-full w-full object-cover" />
                ) : (
                  <FileVideo className="h-6 w-6 text-muted-foreground" />
                )}
              </div>
              <div className="min-w-0">
                <p className="font-medium text-sm truncate">{result.title}</p>
                <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                  {result.licenseNote}
                </p>
              </div>
            </GlassCard>

            <div className="space-y-3">
              {result.options.map((opt) => {
                const key = `${opt.format}-${opt.quality}`;
                const isDownloading = downloadingKey === key;
                return (
                  <GlassCard key={key} className="p-4 flex items-center gap-4">
                    <div className="h-11 w-11 rounded-lg bg-muted flex items-center justify-center shrink-0 uppercase text-xs font-bold text-primary">
                      {opt.format}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{opt.quality}</p>
                      <p className="text-xs text-muted-foreground">{formatBytes(opt.fileSizeKB)}</p>
                      {isDownloading && (
                        <div className="mt-2 h-1.5 w-full rounded-full bg-muted overflow-hidden">
                          <motion.div
                            className="h-full bg-gradient-to-r from-primary to-accent"
                            animate={{ width: `${progress}%` }}
                            transition={{ ease: "easeOut" }}
                          />
                        </div>
                      )}
                    </div>
                    <button
                      onClick={() => handleDownload(opt)}
                      disabled={isDownloading}
                      className="shrink-0 flex items-center gap-1.5 rounded-lg border border-border px-3.5 py-2 text-xs font-semibold hover:bg-muted transition disabled:opacity-60"
                    >
                      {isDownloading ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Download className="h-3.5 w-3.5" />
                      )}
                      {isDownloading ? `${Math.round(progress)}%` : "Download"}
                    </button>
                  </GlassCard>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
