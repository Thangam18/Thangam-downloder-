"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BrainCircuit } from "lucide-react";

const STORAGE_KEY = "mediahub_ai_intro_seen";

export function AIIntroAnimation({ onDone }: { onDone: () => void }) {
  const [show, setShow] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const seen = typeof window !== "undefined" && localStorage.getItem(STORAGE_KEY);
    if (!seen) {
      setShow(true);
    } else {
      onDone();
    }
    setChecked(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function finish() {
    localStorage.setItem(STORAGE_KEY, "1");
    setShow(false);
    onDone();
  }

  if (!checked || !show) return null;

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background"
          exit={{ opacity: 0, transition: { duration: 0.6 } }}
        >
          <div className="absolute inset-0 bg-aurora opacity-30 animate-pulse-glow" />

          <motion.div
            className="relative"
            initial={{ scale: 0.4, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          >
            <motion.div
              className="absolute inset-0 rounded-full bg-primary/30 blur-3xl"
              animate={{ scale: [1, 1.4, 1] }}
              transition={{ duration: 2.4, repeat: Infinity }}
            />
            <div className="relative h-24 w-24 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl">
              <motion.div animate={{ rotate: 360 }} transition={{ duration: 6, repeat: Infinity, ease: "linear" }}>
                <BrainCircuit className="h-11 w-11 text-white" />
              </motion.div>
            </div>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="mt-8 text-2xl sm:text-3xl font-display font-bold"
          >
            Meet <span className="text-gradient">Nova</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.0 }}
            className="mt-3 max-w-sm text-center text-sm text-muted-foreground px-6"
          >
            Your always-on AI assistant — ask questions, brainstorm, get things
            explained, and pick up right where you left off.
          </motion.p>

          <motion.button
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.6 }}
            onClick={finish}
            className="mt-9 px-6 py-2.5 rounded-full bg-gradient-to-r from-primary to-accent text-white text-sm font-semibold shadow-lg shadow-primary/30 hover:opacity-90 transition"
          >
            Start chatting
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
