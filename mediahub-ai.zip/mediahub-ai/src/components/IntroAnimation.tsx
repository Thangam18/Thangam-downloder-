"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles } from "lucide-react";

const SESSION_KEY = "mediahub_intro_seen";
const AUTO_DISMISS_MS = 3200;

export function IntroAnimation() {
  const [visible, setVisible] = useState(false);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    const seen = typeof window !== "undefined" && sessionStorage.getItem(SESSION_KEY);
    if (!seen) {
      setVisible(true);
    }
    setChecked(true);
  }, []);

  useEffect(() => {
    if (!visible) return;
    const timer = setTimeout(dismiss, AUTO_DISMISS_MS);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  function dismiss() {
    sessionStorage.setItem(SESSION_KEY, "1");
    setVisible(false);
  }

  if (!checked || !visible) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background overflow-hidden"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5 } }}
        >
          <div className="absolute inset-0 bg-aurora opacity-40 animate-pulse-glow" />
          <div className="absolute inset-0 bg-grid-glow" />

          <motion.div
            initial={{ scale: 0.6, opacity: 0, rotate: -20 }}
            animate={{ scale: 1, opacity: 1, rotate: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative z-10 h-20 w-20 rounded-3xl bg-gradient-to-br from-primary to-accent flex items-center justify-center shadow-2xl shadow-primary/40"
          >
            <Sparkles className="h-9 w-9 text-white" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="relative z-10 mt-6 text-3xl sm:text-4xl font-display font-bold text-gradient"
          >
            MediaHub AI
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9, duration: 0.6 }}
            className="relative z-10 mt-2 text-sm text-muted-foreground tracking-wide"
          >
            Next-generation media & intelligence platform
          </motion.p>

          <motion.button
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.3 }}
            onClick={dismiss}
            className="relative z-10 mt-10 text-xs font-medium text-muted-foreground hover:text-foreground border border-border rounded-full px-4 py-1.5 transition-colors"
          >
            Skip intro
          </motion.button>

          {/* Floating particles */}
          {Array.from({ length: 14 }).map((_, i) => (
            <motion.span
              key={i}
              className="absolute h-1.5 w-1.5 rounded-full bg-primary/60"
              style={{
                left: `${(i * 37) % 100}%`,
                top: `${(i * 53) % 100}%`
              }}
              animate={{ y: [0, -20, 0], opacity: [0.2, 0.8, 0.2] }}
              transition={{ duration: 3 + (i % 4), repeat: Infinity, delay: i * 0.15 }}
            />
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
