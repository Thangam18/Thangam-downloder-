import { cn } from "@/lib/utils";

export function GlassCard({
  children,
  className,
  glow = false
}: {
  children: React.ReactNode;
  className?: string;
  glow?: boolean;
}) {
  return (
    <div
      className={cn(
        "glass rounded-2xl shadow-xl shadow-black/5",
        glow && "glow-border",
        className
      )}
    >
      {children}
    </div>
  );
}
