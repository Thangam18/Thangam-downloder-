"use client";

import { Toaster } from "react-hot-toast";

export function ToastProvider({ children }: { children: React.ReactNode }) {
  return (
    <>
      {children}
      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: "hsl(var(--surface))",
            color: "hsl(var(--foreground))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "12px",
            fontSize: "14px"
          },
          success: { iconTheme: { primary: "hsl(190 95% 55%)", secondary: "white" } },
          error: { iconTheme: { primary: "#ef4444", secondary: "white" } }
        }}
      />
    </>
  );
}
