"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import { Search, Trash2, Download, Sparkles, ShieldCheck, Inbox } from "lucide-react";
import { GlassCard } from "@/components/GlassCard";
import { Skeleton } from "@/components/LoadingSkeleton";

interface HistoryItem {
  id: string;
  type: string;
  label: string;
  createdAt: string;
}

const ICONS: Record<string, any> = {
  download: Download,
  ai_chat: Sparkles,
  account: ShieldCheck
};

export function HistoryList() {
  const [items, setItems] = useState<HistoryItem[] | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<string>("");

  async function load() {
    const params = new URLSearchParams();
    if (query) params.set("q", query);
    if (filter) params.set("type", filter);

    const res = await fetch(`/api/history?${params.toString()}`);
    const data = await res.json();
    if (res.ok) setItems(data.items);
    else toast.error(data.error ?? "Couldn't load history.");
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  async function deleteItem(id: string) {
    const res = await fetch(`/api/history/${id}`, { method: "DELETE" });
    if (res.ok) {
      setItems((prev) => prev?.filter((i) => i.id !== id) ?? null);
      toast.success("Removed from history.");
    } else {
      toast.error("Couldn't remove that item.");
    }
  }

  async function clearAll() {
    const res = await fetch("/api/history", { method: "DELETE" });
    if (res.ok) {
      setItems([]);
      toast.success("History cleared.");
    } else {
      toast.error("Couldn't clear history.");
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search your history…"
            className="w-full glass rounded-xl pl-9 pr-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/40"
          />
        </div>
        <div className="flex gap-2">
          {["", "download", "ai_chat", "account"].map((t) => (
            <button
              key={t || "all"}
              onClick={() => setFilter(t)}
              className={`px-3 py-2 rounded-lg text-xs font-medium border transition ${
                filter === t ? "bg-primary text-white border-primary" : "border-border hover:bg-muted"
              }`}
            >
              {t === "" ? "All" : t === "ai_chat" ? "AI Chats" : t[0].toUpperCase() + t.slice(1)}
            </button>
          ))}
          <button
            onClick={clearAll}
            className="px-3 py-2 rounded-lg text-xs font-medium border border-red-500/40 text-red-400 hover:bg-red-500/10 transition"
          >
            Clear all
          </button>
        </div>
      </div>

      {items === null && (
        <div className="space-y-2">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-14 w-full" />
          ))}
        </div>
      )}

      {items?.length === 0 && (
        <GlassCard className="p-10 flex flex-col items-center text-center gap-2">
          <Inbox className="h-8 w-8 text-muted-foreground" />
          <p className="text-sm font-medium">No history yet</p>
          <p className="text-xs text-muted-foreground">Your downloads and AI chats will show up here.</p>
        </GlassCard>
      )}

      <AnimatePresence>
        {items?.map((item) => {
          const Icon = ICONS[item.type] ?? Inbox;
          return (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 8 }}
            >
              <GlassCard className="p-3.5 flex items-center gap-3">
                <div className="h-9 w-9 rounded-lg bg-muted flex items-center justify-center shrink-0">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{new Date(item.createdAt).toLocaleString()}</p>
                </div>
                <button
                  onClick={() => deleteItem(item.id)}
                  aria-label="Delete history item"
                  className="p-2 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </GlassCard>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
