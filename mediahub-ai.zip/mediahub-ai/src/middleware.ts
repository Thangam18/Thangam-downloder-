import { NextRequest, NextResponse } from "next/server";

// NextAuth's credentials flow already uses a same-site, HttpOnly,
// signed cookie (CSRF token baked in for its own endpoints). For our
// custom API routes, we add a same-origin check on state-changing
// methods as defense in depth against cross-site request forgery.
const MUTATING_METHODS = new Set(["POST", "PATCH", "PUT", "DELETE"]);

export function middleware(req: NextRequest) {
  if (req.nextUrl.pathname.startsWith("/api/") && MUTATING_METHODS.has(req.method)) {
    const origin = req.headers.get("origin");
    const host = req.headers.get("host");

    if (origin && host) {
      const originHost = new URL(origin).host;
      if (originHost !== host) {
        return NextResponse.json({ error: "Cross-origin request blocked." }, { status: 403 });
      }
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: "/api/:path*"
};
