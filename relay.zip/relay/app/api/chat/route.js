// Server-only route. The API key lives here and is never sent to the browser.
// The client (lib/coreClient.js) calls this route instead of api.anthropic.com directly.

const MODEL = "claude-sonnet-4-6"; // see https://docs.claude.com for current model ids
const MAX_TOKENS = 1024;
const MAX_MESSAGES = 40;
const MAX_PAYLOAD_BYTES = 6 * 1024 * 1024; // ~6MB, generous enough for one image/pdf attachment

const CORE_SYSTEM_PROMPT = `You are Core, the AI assistant built into Relay, a media-download companion app.
You help with general questions, writing, coding, summarization, translation, and text/document analysis.
You can also explain how Relay works: paste a URL into the Downloader tab, Relay detects the platform and
content type, and offers real downloads for direct file links and open-license sources — but it does not
offer downloads for platforms whose terms of service prohibit it (e.g. YouTube, Instagram, TikTok, X,
Facebook, SoundCloud, Spotify, Vimeo), since that would violate those platforms' rules and copyright law.
You have web search available for looking up current information, including background on a URL or topic
a person shares — but you cannot open, render, or download a page yourself, only reason about search results
and whatever text or files the person gives you directly. If someone asks you to fetch, download, or convert
a specific file, tell them plainly that isn't something you can do from chat, and point them to the Downloader
tab. Keep answers concise, precise and warm. Use markdown — fenced code blocks for code, short headers and
lists for structure — only when it actually helps.`;

// Simple in-memory sliding-window rate limiter. Fine for a single instance / demo use.
// For multi-instance production deployments, swap this for Redis (e.g. Upstash) so limits
// are shared across servers.
const RATE_LIMIT = 20; // requests
const RATE_WINDOW_MS = 60_000; // per minute
const buckets = new Map();

function isRateLimited(ip) {
  const now = Date.now();
  const windowStart = now - RATE_WINDOW_MS;
  const hits = (buckets.get(ip) || []).filter((t) => t > windowStart);
  hits.push(now);
  buckets.set(ip, hits);
  if (buckets.size > 5000) {
    // basic cleanup so the map doesn't grow unbounded
    for (const [key, arr] of buckets) {
      if (!arr.some((t) => t > windowStart)) buckets.delete(key);
    }
  }
  return hits.length > RATE_LIMIT;
}

function badRequest(message) {
  return Response.json({ error: message }, { status: 400 });
}

export async function POST(req) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
  if (isRateLimited(ip)) {
    return Response.json(
      { error: "Too many requests. Wait a moment before trying again." },
      { status: 429 }
    );
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "Server is missing ANTHROPIC_API_KEY. Add it to .env.local and restart the dev server." },
      { status: 500 }
    );
  }

  const contentLength = Number(req.headers.get("content-length") || 0);
  if (contentLength > MAX_PAYLOAD_BYTES) {
    return badRequest("Request payload is too large.");
  }

  let body;
  try {
    body = await req.json();
  } catch {
    return badRequest("Request body must be valid JSON.");
  }

  const { messages } = body || {};
  if (!Array.isArray(messages) || messages.length === 0) {
    return badRequest("`messages` must be a non-empty array.");
  }
  if (messages.length > MAX_MESSAGES) {
    return badRequest(`Conversation is too long — trim to ${MAX_MESSAGES} messages or fewer.`);
  }
  for (const m of messages) {
    if (!m || (m.role !== "user" && m.role !== "assistant")) {
      return badRequest("Each message needs a role of 'user' or 'assistant'.");
    }
  }

  let upstream;
  try {
    upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        stream: true,
        system: CORE_SYSTEM_PROMPT,
        tools: [{ type: "web_search_20250305", name: "web_search" }],
        messages,
      }),
    });
  } catch {
    return Response.json({ error: "Couldn't reach the AI provider. Check server network access." }, { status: 502 });
  }

  if (!upstream.ok || !upstream.body) {
    const detail = await upstream.text().catch(() => "");
    return Response.json(
      { error: "The AI provider returned an error.", detail: detail.slice(0, 500) },
      { status: upstream.status || 502 }
    );
  }

  // Pass the SSE stream straight through to the client.
  return new Response(upstream.body, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
    },
  });
}
