# Relay

A media-download companion with an AI workspace ("Core") built in. Next.js 14 (App Router),
plain JS/JSX, no external UI kit — styling is one hand-written CSS file using CSS variables.

## Quick start

```bash
npm install
cp .env.example .env.local   # then add your ANTHROPIC_API_KEY
npm run dev
```

Open http://localhost:3000. Without an API key, everything works except Core's replies —
you'll get a clear in-app error telling you the server key is missing, not a silent failure.

Get a key at https://console.anthropic.com.

## What's actually real here

- **Core (the AI assistant)** — genuine streamed responses from the Claude API, with web
  search wired in, via `app/api/chat/route.js`. Your API key stays server-side; the browser
  only ever talks to `/api/chat` on your own domain.
- **Direct file link downloads** — a URL that points straight at a `.mp4`/`.mp3`/`.jpg`/etc.
  downloads for real, handed off to the browser.
- **Platform detection** — real pattern matching that gives an honest, specific explanation
  for platforms that don't allow downloading (YouTube, Instagram, TikTok, etc.) instead of
  pretending to process them.
- **Profile, download history, saved items, conversation history** — persisted in
  `localStorage` via `lib/storage.js`, so they survive refreshes on the same device/browser.

## What's still a stand-in

- **Auth** — `components/auth/AuthModal.jsx` creates a local profile (name/email/avatar) with
  no password. It's enough to demo the UX, but it isn't real authentication. See
  [Adding real auth](#adding-real-auth-and-a-database) below.
- **The "Try a sample" download flow** — clearly labeled in the UI as a sample. It exists to
  show off the format-picker / progress-bar experience without pretending to rip a real file
  from a platform that doesn't allow it.
- **Rate limiting** on `/api/chat` is in-memory (per server instance) — fine for a single
  deployment, but swap it for Redis (e.g. Upstash) if you run multiple instances.

## Project structure

```
app/
  layout.js            root layout, loads fonts via next/font
  page.js               mounts the client app
  globals.css           the entire visual theme (CSS variables + component classes)
  api/chat/route.js     server route: validates input, rate-limits, proxies Claude, streams back
components/
  App.jsx               view routing + top-level state (profile, theme, history, conversations)
  nav/                  TopNav (desktop), BottomNav (mobile)
  ui/                   Toast, and small primitives (Btn, Card, Modal, Badge, ...)
  landing/               marketing page
  downloader/            paste-a-URL flow
  ai/                    Core chat workspace
  auth/                  profile modal
  dashboard/              stats + recent activity
  settings/               profile editing, theme, data reset
lib/
  constants.js           copy, platform patterns, nav items
  helpers.js              uid/sleep/formatBytes/detectUrl
  markdown.jsx             tiny markdown-to-JSX renderer for chat messages
  storage.js               localStorage wrapper
  coreClient.js             client-side fetch + SSE parsing for /api/chat
```

## Adding real auth and a database

The cleanest next step is to replace `lib/storage.js` and `AuthModal.jsx` with:

1. An auth provider (e.g. [Auth.js](https://authjs.dev), [Clerk](https://clerk.com), or a
   custom email+password flow with hashed passwords) protecting a few new API routes.
2. A real database (Postgres via [Prisma](https://www.prisma.io) or
   [Drizzle](https://orm.drizzle.team) works well with Next.js) with tables for `users`,
   `downloads`, `saved_items`, and `conversations`.
3. Swap the `storage.get/set` calls in `components/App.jsx` for `fetch()` calls to your new
   API routes, keyed by the authenticated user's session instead of the browser.

Everything else — the component structure, the Core chat logic, the downloader UI — stays
the same; only the persistence layer changes.

## Notes

- Icons: [lucide-react](https://lucide.dev). Charts: [recharts](https://recharts.org).
- No TypeScript yet — the component boundaries are already clean, so adding `.tsx` +
  interfaces later is mostly mechanical if you want it.
- Deploys cleanly to Vercel; set `ANTHROPIC_API_KEY` in your project's environment variables.
