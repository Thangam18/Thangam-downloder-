"use client";

import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";
import {
  Download, MessageSquare, Star, Bell, BarChart3, Activity, Music, Video,
  Image as ImageIcon, Bookmark, Sparkles,
} from "lucide-react";
import { Card, EmptyState } from "@/components/ui/Primitives";
import { formatBytes } from "@/lib/helpers";

export default function Dashboard({ profile, history, saved, conversations, setView, toggleSave }) {
  const chartData = (() => {
    const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const counts = days.map((d) => ({ day: d, downloads: 0 }));
    history.forEach((h) => {
      const idx = new Date(h.date).getDay();
      counts[idx].downloads += 1;
    });
    return counts;
  })();

  const hasActivity = history.length > 0;

  return (
    <div className="view-shell">
      <div className="view-head">
        <h1>Welcome back, {profile.name.split(" ")[0]}</h1>
        <p>Here's what's been happening across Relay and Core.</p>
      </div>

      <div className="stat-grid">
        <Card className="stat-card"><Download size={16} /><div><span>{history.length}</span><label>Downloads</label></div></Card>
        <Card className="stat-card"><MessageSquare size={16} /><div><span>{conversations.length}</span><label>Core chats</label></div></Card>
        <Card className="stat-card"><Star size={16} /><div><span>{saved.length}</span><label>Saved items</label></div></Card>
        <Card className="stat-card"><Bell size={16} /><div><span>0</span><label>Notifications</label></div></Card>
      </div>

      <div className="dash-grid">
        <Card className="dash-panel">
          <div className="dash-panel-head"><h3><BarChart3 size={15} /> Weekly activity</h3></div>
          {hasActivity ? (
            <div style={{ width: "100%", height: 180 }}>
              <ResponsiveContainer>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                  <XAxis dataKey="day" stroke="var(--text-faint)" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="var(--text-faint)" fontSize={12} allowDecimals={false} tickLine={false} axisLine={false} width={24} />
                  <Tooltip contentStyle={{ background: "var(--surface-solid)", border: "1px solid var(--border)", borderRadius: 10, color: "var(--text)" }} />
                  <Bar dataKey="downloads" fill="var(--cyan)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <EmptyState icon={Activity} title="No activity yet" body="Your download activity will show up here once you start using the Downloader." />
          )}
        </Card>

        <Card className="dash-panel">
          <div className="dash-panel-head"><h3><Download size={15} /> Recent downloads</h3><button onClick={() => setView("downloader")}>Open downloader</button></div>
          {history.length === 0 ? (
            <EmptyState icon={Download} title="Nothing downloaded yet" body="Items you download will appear here." />
          ) : (
            <ul className="history-list">
              {history.slice(0, 5).map((h) => (
                <li key={h.id}>
                  <div className="history-icon">{h.kind === "audio" ? <Music size={14} /> : h.kind === "image" ? <ImageIcon size={14} /> : <Video size={14} />}</div>
                  <div className="history-meta">
                    <span className="history-title">{h.title}</span>
                    <span className="history-sub">{h.quality} · {formatBytes(h.size)}</span>
                  </div>
                  <button className="save-toggle" onClick={() => toggleSave(h)} aria-label="Save item"><Star size={14} fill={saved.some((s) => s.id === h.id) ? "currentColor" : "none"} /></button>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="dash-panel">
          <div className="dash-panel-head"><h3><MessageSquare size={15} /> Recent Core chats</h3><button onClick={() => setView("ai")}>Open Core</button></div>
          {conversations.length === 0 ? (
            <EmptyState icon={MessageSquare} title="No conversations yet" body="Ask Core something to get started." />
          ) : (
            <ul className="history-list">
              {conversations.slice(0, 5).map((c) => (
                <li key={c.id}>
                  <div className="history-icon"><Sparkles size={14} /></div>
                  <div className="history-meta">
                    <span className="history-title">{c.title}</span>
                    <span className="history-sub">{c.messages.length} messages</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="dash-panel">
          <div className="dash-panel-head"><h3><Star size={15} /> Saved items</h3></div>
          {saved.length === 0 ? (
            <EmptyState icon={Star} title="Nothing saved" body="Star a download to keep it handy here." />
          ) : (
            <ul className="history-list">
              {saved.map((h) => (
                <li key={h.id}>
                  <div className="history-icon"><Bookmark size={14} /></div>
                  <div className="history-meta"><span className="history-title">{h.title}</span><span className="history-sub">{h.quality}</span></div>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
