"use client";

import { useState } from "react";
import {
  Link2, ArrowRight, Sparkles, Lock, ShieldCheck, Activity, FileText,
  ArrowUpRight, ChevronDown, Zap,
} from "lucide-react";
import { Btn, Badge, Card } from "@/components/ui/Primitives";
import {
  SUPPORTED_GRID, FEATURES, AI_CAPABILITIES, HOW_IT_WORKS, FAQS, TESTIMONIALS,
} from "@/lib/constants";

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="faq-item">
      <button className="faq-q" onClick={() => setOpen((v) => !v)}>
        <span>{q}</span>
        <ChevronDown size={16} className={open ? "faq-chevron-open" : ""} />
      </button>
      {open ? <div className="faq-a">{a}</div> : null}
    </div>
  );
}

function DashboardPreviewCard({ onOpen }) {
  return (
    <Card className="dash-preview" glow>
      <div className="dash-preview-grid">
        <div className="dash-preview-stat"><span>128</span><label>Downloads</label></div>
        <div className="dash-preview-stat"><span>34</span><label>Core chats</label></div>
        <div className="dash-preview-stat"><span>19</span><label>Saved items</label></div>
      </div>
      <div className="dash-preview-bars" aria-hidden="true">
        {[40, 65, 30, 80, 55, 90, 45].map((h, i) => <span key={i} style={{ height: `${h}%` }} />)}
      </div>
      <Btn variant="secondary" icon={ArrowUpRight} onClick={onOpen}>Open your dashboard</Btn>
    </Card>
  );
}

export default function Landing({ setView, onAuthOpen, profile }) {
  const [heroUrl, setHeroUrl] = useState("");
  return (
    <div className="landing">
      <section className="hero">
        <div className="aurora" aria-hidden="true" />
        <div className="hero-inner">
          <Badge tone="violet">AI-assisted detection</Badge>
          <h1 className="hero-title">Paste a link.<br />Get the file.</h1>
          <p className="hero-sub">
            Relay reads the URL, works out what's on the other end, and hands you the right format —
            video, audio or image. Stuck on something else entirely? Core, the AI workspace next door,
            will just talk you through it.
          </p>
          <div className="hero-input-row">
            <div className="hero-input">
              <Link2 size={16} className="hero-input-icon" />
              <input
                value={heroUrl}
                onChange={(e) => setHeroUrl(e.target.value)}
                placeholder="Paste any media URL…"
                onKeyDown={(e) => { if (e.key === "Enter") setView("downloader"); }}
                aria-label="Media URL"
              />
              <div className="scanline" aria-hidden="true" />
            </div>
            <Btn icon={ArrowRight} onClick={() => setView("downloader")}>Detect</Btn>
          </div>
          <div className="hero-actions">
            <button className="hero-ai-cta" onClick={() => setView("ai")}>
              <Sparkles size={15} /> Or open the AI workspace
            </button>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Where Relay looks</h2>
          <p>Detection covers every link below. Full downloads run wherever the source actually allows it.</p>
        </div>
        <div className="platform-grid">
          {SUPPORTED_GRID.map((p) => (
            <div key={p.name} className="platform-tile">
              <span className="platform-name">{p.name}</span>
              <span className="platform-note">{p.note}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>Built to be trusted with the details</h2>
          <p>Every piece of the download flow is designed to be predictable, not clever.</p>
        </div>
        <div className="feature-grid">
          {FEATURES.map((f) => (
            <Card key={f.title} className="feature-card">
              <div className="feature-icon"><f.icon size={18} /></div>
              <h3>{f.title}</h3>
              <p>{f.body}</p>
            </Card>
          ))}
        </div>
      </section>

      <section className="section section-ai">
        <div className="ai-showcase">
          <div className="ai-showcase-copy">
            <Badge tone="cyan">Core</Badge>
            <h2>An AI workspace that's actually the main event</h2>
            <p>
              Core isn't a help-bubble bolted onto a corner of the screen. It's a full workspace with
              conversation history, streaming answers, file understanding and a live connection to
              current information on the web.
            </p>
            <Btn icon={Sparkles} onClick={() => setView("ai")}>Open Core</Btn>
          </div>
          <div className="ai-capability-grid">
            {AI_CAPABILITIES.map((c) => (
              <div key={c.title} className="ai-capability-tile">
                <c.icon size={16} />
                <div>
                  <div className="ai-capability-title">{c.title}</div>
                  <div className="ai-capability-body">{c.body}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>How it works</h2>
        </div>
        <div className="steps-row">
          {HOW_IT_WORKS.map((s, idx) => (
            <div key={s.step} className="step-tile">
              <div className="step-number">{idx + 1}</div>
              <div className="step-title">{s.step}</div>
              <div className="step-body">{s.body}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="security-panel">
          <div className="security-copy">
            <Badge tone="mint">Security</Badge>
            <h2>Nothing hides in the frontend</h2>
            <p>
              Downloads are validated and processed server-side, credentials never touch the browser,
              and Relay only completes a job where the source's own rules permit it. Your history and
              saved items are private to your account.
            </p>
          </div>
          <ul className="security-list">
            <li><Lock size={14} /> Server-side validation on every request</li>
            <li><ShieldCheck size={14} /> No API keys or secrets in client code</li>
            <li><Activity size={14} /> Rate limiting and abuse prevention</li>
            <li><FileText size={14} /> File-size limits enforced before processing</li>
          </ul>
        </div>
      </section>

      <section className="section">
        <div className="section-head">
          <h2>A dashboard that stays out of your way</h2>
          <p>Everything you've downloaded, saved, and asked Core lives in one place.</p>
        </div>
        <DashboardPreviewCard onOpen={() => (profile ? setView("dashboard") : onAuthOpen())} />
      </section>

      <section className="section">
        <div className="section-head"><h2>What people use it for</h2></div>
        <div className="testimonial-grid">
          {TESTIMONIALS.map((t) => (
            <Card key={t.name} className="testimonial-card">
              <p>"{t.body}"</p>
              <div className="testimonial-name">{t.name}</div>
              <div className="testimonial-role">{t.role}</div>
            </Card>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Questions</h2></div>
        <div className="faq-list">
          {FAQS.map((f) => <FaqItem key={f.q} q={f.q} a={f.a} />)}
        </div>
      </section>

      <footer className="footer">
        <div className="footer-top">
          <div className="brand">
            <span className="brand-mark"><Zap size={16} /></span>
            <span className="brand-name">Relay</span>
          </div>
          <p>A media-download companion with an AI workspace built in.</p>
        </div>
        <div className="footer-cols">
          <div>
            <h4>Product</h4>
            <button onClick={() => setView("downloader")}>Downloader</button>
            <button onClick={() => setView("ai")}>Core AI</button>
            <button onClick={() => (profile ? setView("dashboard") : onAuthOpen())}>Dashboard</button>
          </div>
          <div>
            <h4>Company</h4>
            <span>Security</span>
            <span>Privacy</span>
            <span>Terms</span>
          </div>
        </div>
        <div className="footer-bottom">© {new Date().getFullYear()} Relay. Preview build.</div>
      </footer>
    </div>
  );
}
