"use client";

import { useState, useEffect } from "react";
import { ToastProvider, useToast } from "@/components/ui/Toast";
import TopNav from "@/components/nav/TopNav";
import BottomNav from "@/components/nav/BottomNav";
import Landing from "@/components/landing/Landing";
import Downloader from "@/components/downloader/Downloader";
import AIAssistant from "@/components/ai/AIAssistant";
import AuthModal from "@/components/auth/AuthModal";
import Dashboard from "@/components/dashboard/Dashboard";
import Settings from "@/components/settings/Settings";
import { storage } from "@/lib/storage";

function AppInner() {
  const toast = useToast();
  const [view, setView] = useState("landing");
  const [theme, setTheme] = useState("dark");
  const [profile, setProfile] = useState(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [history, setHistory] = useState([]);
  const [saved, setSaved] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [dataLoaded, setDataLoaded] = useState(false);

  // Load profile + data from local storage on mount
  useEffect(() => {
    (async () => {
      try {
        const res = await storage.get("relay-profile");
        if (res?.value) setProfile(JSON.parse(res.value));
      } catch { /* no profile yet */ }
      try {
        const lib = await storage.get("relay-library");
        if (lib?.value) {
          const parsed = JSON.parse(lib.value);
          setHistory(parsed.history || []);
          setSaved(parsed.saved || []);
        }
      } catch { /* empty */ }
      try {
        const convo = await storage.get("relay-conversations");
        if (convo?.value) setConversations(JSON.parse(convo.value));
      } catch { /* empty */ }
      setDataLoaded(true);
    })();
  }, []);

  // Persist library + conversations when they change (after initial load)
  useEffect(() => {
    if (!dataLoaded) return;
    storage.set("relay-library", JSON.stringify({ history: history.slice(0, 100), saved: saved.slice(0, 100) })).catch(() => {});
  }, [history, saved, dataLoaded]);

  useEffect(() => {
    if (!dataLoaded) return;
    storage.set("relay-conversations", JSON.stringify(conversations.slice(0, 30))).catch(() => {});
  }, [conversations, dataLoaded]);

  function createProfile(p) {
    setProfile(p);
    storage.set("relay-profile", JSON.stringify(p)).catch(() => {});
    setAuthOpen(false);
    toast({ tone: "success", title: `Welcome, ${p.name.split(" ")[0]}`, body: "Your profile is saved to this browser." });
    setView("dashboard");
  }

  function updateProfile(p) {
    setProfile(p);
    storage.set("relay-profile", JSON.stringify(p)).catch(() => {});
  }

  function logout() {
    setProfile(null);
    setView("landing");
    toast({ tone: "info", title: "Logged out", body: "Your data is still saved for next time." });
  }

  function resetData() {
    setHistory([]);
    setSaved([]);
    setConversations([]);
    storage.set("relay-library", JSON.stringify({ history: [], saved: [] })).catch(() => {});
    storage.set("relay-conversations", JSON.stringify([])).catch(() => {});
    toast({ tone: "success", title: "Data cleared" });
  }

  function addHistory(item) {
    setHistory((prev) => [item, ...prev].slice(0, 100));
  }

  function toggleSave(item) {
    setSaved((prev) => (prev.some((s) => s.id === item.id) ? prev.filter((s) => s.id !== item.id) : [item, ...prev]));
  }

  const guardedView = (view === "dashboard" || view === "settings") && !profile ? "landing" : view;

  return (
    <div className={`app-root theme-${theme}`}>
      <TopNav view={guardedView} setView={setView} profile={profile} onAuthOpen={() => setAuthOpen(true)} onLogout={logout} theme={theme} setTheme={setTheme} />

      <main className="app-main">
        {guardedView === "landing" ? <Landing setView={setView} onAuthOpen={() => setAuthOpen(true)} profile={profile} /> : null}
        {guardedView === "downloader" ? <Downloader addHistory={addHistory} profile={profile} onAuthOpen={() => setAuthOpen(true)} /> : null}
        {guardedView === "ai" ? <AIAssistant conversations={conversations} setConversations={setConversations} profile={profile} onAuthOpen={() => setAuthOpen(true)} /> : null}
        {guardedView === "dashboard" && profile ? <Dashboard profile={profile} history={history} saved={saved} conversations={conversations} setView={setView} toggleSave={toggleSave} /> : null}
        {guardedView === "settings" && profile ? <Settings profile={profile} updateProfile={updateProfile} theme={theme} setTheme={setTheme} onLogout={logout} onResetData={resetData} /> : null}
      </main>

      <BottomNav view={guardedView} setView={setView} profile={profile} onAuthOpen={() => setAuthOpen(true)} />

      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} onCreateProfile={createProfile} existingProfile={profile} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <AppInner />
    </ToastProvider>
  );
}
