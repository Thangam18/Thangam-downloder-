"use client";

import { X } from "lucide-react";

export function Btn({ children, variant = "primary", size = "md", icon: Icon, onClick, disabled, className = "", type = "button", title }) {
  return (
    <button
      type={type}
      title={title}
      disabled={disabled}
      onClick={onClick}
      className={`btn btn-${variant} btn-${size} ${disabled ? "btn-disabled" : ""} ${className}`}
    >
      {Icon ? <Icon size={size === "sm" ? 14 : 16} /> : null}
      <span>{children}</span>
    </button>
  );
}

export function Badge({ children, tone = "default" }) {
  return <span className={`badge badge-${tone}`}>{children}</span>;
}

export function Card({ children, className = "", glow = false }) {
  return <div className={`card ${glow ? "card-glow" : ""} ${className}`}>{children}</div>;
}

export function Skeleton({ w = "100%", h = "14px", r = "8px" }) {
  return <div className="skeleton" style={{ width: w, height: h, borderRadius: r }} />;
}

export function ProgressBar({ value }) {
  return (
    <div className="progress-track">
      <div className="progress-fill" style={{ width: `${Math.min(100, value)}%` }} />
    </div>
  );
}

export function EmptyState({ icon: Icon, title, body, action }) {
  return (
    <div className="empty-state">
      <div className="empty-icon"><Icon size={22} /></div>
      <div className="empty-title">{title}</div>
      <div className="empty-body">{body}</div>
      {action}
    </div>
  );
}

export function Modal({ open, onClose, children, width = 440 }) {
  if (!open) return null;
  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-panel" style={{ maxWidth: width }} role="dialog" aria-modal="true">
        <button className="modal-close" onClick={onClose} aria-label="Close dialog"><X size={16} /></button>
        {children}
      </div>
    </div>
  );
}

export function Avatar({ name, color, size = 36 }) {
  const initial = (name || "?").trim().charAt(0).toUpperCase();
  return (
    <div className="avatar" style={{ width: size, height: size, fontSize: size * 0.42, background: `linear-gradient(135deg, ${color}, ${color}99)` }}>
      {initial}
    </div>
  );
}
