"use client";

import { createContext, useContext, useCallback, useState } from "react";
import { CheckCircle2, AlertTriangle, Info } from "lucide-react";
import { uid } from "@/lib/helpers";

const ToastContext = createContext(null);

export function useToast() {
  return useContext(ToastContext);
}

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((toast) => {
    const id = uid();
    setToasts((t) => [...t, { id, tone: "info", ...toast }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4200);
  }, []);

  return (
    <ToastContext.Provider value={push}>
      {children}
      <div className="toast-stack">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.tone}`}>
            {t.tone === "success" ? <CheckCircle2 size={16} /> : t.tone === "error" ? <AlertTriangle size={16} /> : <Info size={16} />}
            <div>
              <div className="toast-title">{t.title}</div>
              {t.body ? <div className="toast-body">{t.body}</div> : null}
            </div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
