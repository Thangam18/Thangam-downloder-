"use client";

import { useState, useRef, useEffect } from "react";
import {
  Plus, Trash2, Sparkles, X, Paperclip, AlertTriangle, Copy, RefreshCw, Send, Loader2,
} from "lucide-react";
import { Btn } from "@/components/ui/Primitives";
import { useToast } from "@/components/ui/Toast";
import { uid } from "@/lib/helpers";
import { streamCore, fileToBase64 } from "@/lib/coreClient";
import { renderMarkdown } from "@/lib/markdown";
import { SUGGESTED_PROMPTS } from "@/lib/constants";

export default function AIAssistant({ conversations, setConversations, profile, onAuthOpen }) {
  const toast = useToast();
  const [activeId, setActiveId] = useState(conversations[0]?.id || null);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [attachment, setAttachment] = useState(null);
  const fileRef = useRef(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (!activeId && conversations.length) setActiveId(conversations[0].id);
  }, [conversations, activeId]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  });

  const active = conversations.find((c) => c.id === activeId) || null;

  function newConversation() {
    const convo = { id: uid(), title: "New conversation", messages: [], createdAt: Date.now() };
    setConversations((prev) => [convo, ...prev]);
    setActiveId(convo.id);
  }

  function clearChat() {
    if (!active) return;
    setConversations((prev) => prev.map((c) => (c.id === active.id ? { ...c, messages: [] } : c)));
  }

  function deleteConversation(id) {
    setConversations((prev) => prev.filter((c) => c.id !== id));
    if (activeId === id) setActiveId(null);
  }

  async function handleFilePick(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ tone: "error", title: "File too large", body: "Attach something under 5 MB." });
      return;
    }
    if (file.type.startsWith("image/")) {
      const b64 = await fileToBase64(file);
      setAttachment({ kind: "image", name: file.name, mediaType: file.type, data: b64 });
    } else if (file.type === "application/pdf") {
      const b64 = await fileToBase64(file);
      setAttachment({ kind: "pdf", name: file.name, mediaType: file.type, data: b64 });
    } else {
      const text = await file.text();
      setAttachment({ kind: "text", name: file.name, text: text.slice(0, 20000) });
    }
  }

  async function send(overrideText) {
    const text = (overrideText ?? input).trim();
    if (!text && !attachment) return;
    if (streaming) return;

    let convo = active;
    if (!convo) {
      convo = { id: uid(), title: text.slice(0, 40) || "New conversation", messages: [], createdAt: Date.now() };
      setConversations((prev) => [convo, ...prev]);
      setActiveId(convo.id);
    }

    const userContent = [];
    if (attachment?.kind === "image") userContent.push({ type: "image", source: { type: "base64", media_type: attachment.mediaType, data: attachment.data } });
    if (attachment?.kind === "pdf") userContent.push({ type: "document", source: { type: "base64", media_type: attachment.mediaType, data: attachment.data } });
    let textForModel = text;
    if (attachment?.kind === "text") textForModel = `${text}\n\n[Attached file: ${attachment.name}]\n${attachment.text}`;
    userContent.push({ type: "text", text: textForModel || "Take a look at this file." });

    const userMsg = { role: "user", content: userContent, display: text, attachmentName: attachment?.name };
    const assistantMsg = { role: "assistant", content: "", pending: true };

    setConversations((prev) => prev.map((c) => c.id === convo.id
      ? { ...c, title: c.messages.length === 0 ? (text.slice(0, 40) || attachment?.name || "New conversation") : c.title, messages: [...c.messages, userMsg, assistantMsg] }
      : c));

    setInput("");
    setAttachment(null);
    setStreaming(true);

    const history = [...(convo.messages || []), userMsg].map((m) => ({
      role: m.role,
      content: typeof m.content === "string" ? m.content : m.content,
    }));

    try {
      await streamCore(history, (partial) => {
        setConversations((prev) => prev.map((c) => c.id === convo.id
          ? { ...c, messages: c.messages.map((m, idx) => idx === c.messages.length - 1 ? { role: "assistant", content: partial, pending: false } : m) }
          : c));
      });
    } catch {
      setConversations((prev) => prev.map((c) => c.id === convo.id
        ? { ...c, messages: c.messages.map((m, idx) => idx === c.messages.length - 1 ? { role: "assistant", content: "", error: true, pending: false } : m) }
        : c));
      toast({ tone: "error", title: "Core couldn't respond", body: "That request failed — try again in a moment." });
    } finally {
      setStreaming(false);
    }
  }

  function regenerate() {
    if (!active || streaming) return;
    const msgs = active.messages;
    let lastUserIdx = -1;
    for (let i = msgs.length - 1; i >= 0; i--) { if (msgs[i].role === "user") { lastUserIdx = i; break; } }
    if (lastUserIdx === -1) return;
    const trimmed = msgs.slice(0, lastUserIdx + 1);
    setConversations((prev) => prev.map((c) => (c.id === active.id ? { ...c, messages: trimmed } : c)));
    setTimeout(() => resend(active.id, trimmed), 0);
  }

  async function resend(convoId, historyMsgs) {
    const assistantMsg = { role: "assistant", content: "", pending: true };
    setConversations((prev) => prev.map((c) => c.id === convoId ? { ...c, messages: [...c.messages, assistantMsg] } : c));
    setStreaming(true);
    try {
      await streamCore(historyMsgs, (partial) => {
        setConversations((prev) => prev.map((c) => c.id === convoId
          ? { ...c, messages: c.messages.map((m, idx) => idx === c.messages.length - 1 ? { role: "assistant", content: partial, pending: false } : m) }
          : c));
      });
    } catch {
      toast({ tone: "error", title: "Core couldn't respond", body: "That request failed — try again in a moment." });
    } finally {
      setStreaming(false);
    }
  }

  function copyMessage(content) {
    const text = typeof content === "string" ? content : "";
    try {
      navigator.clipboard.writeText(text);
      toast({ tone: "success", title: "Copied to clipboard" });
    } catch {
      toast({ tone: "info", title: "Select and copy manually", body: "Clipboard access is blocked here." });
    }
  }

  return (
    <div className="ai-shell">
      <aside className="ai-sidebar">
        <Btn icon={Plus} onClick={newConversation} className="ai-new-btn">New conversation</Btn>
        <div className="ai-convo-list">
          {conversations.length === 0 ? (
            <div className="ai-convo-empty">No conversations yet</div>
          ) : conversations.map((c) => (
            <div key={c.id} className={`ai-convo-item ${c.id === activeId ? "ai-convo-item-active" : ""}`}>
              <button onClick={() => setActiveId(c.id)}>{c.title || "Untitled"}</button>
              <button className="ai-convo-delete" onClick={() => deleteConversation(c.id)} aria-label="Delete conversation"><Trash2 size={13} /></button>
            </div>
          ))}
        </div>
      </aside>

      <section className="ai-main">
        <div className="ai-topbar">
          <div className="ai-topbar-title"><Sparkles size={16} /> Core</div>
          <div className="ai-topbar-actions">
            <button className="icon-btn" onClick={clearChat} title="Clear chat" aria-label="Clear chat"><X size={15} /></button>
          </div>
        </div>

        <div className="ai-thread" ref={scrollRef}>
          {!active || active.messages.length === 0 ? (
            <div className="ai-welcome">
              <div className="ai-welcome-icon"><Sparkles size={26} /></div>
              <h2>Ask Core anything</h2>
              <p>General questions, writing, code, summaries, translation, or a document you paste in — Core handles it, and searches the web when it needs current information.</p>
              <div className="suggested-row">
                {SUGGESTED_PROMPTS.map((p) => (
                  <button key={p} className="suggested-chip" onClick={() => send(p)}>{p}</button>
                ))}
              </div>
            </div>
          ) : (
            active.messages.map((m, idx) => (
              <div key={idx} className={`chat-row chat-row-${m.role}`}>
                <div className={`chat-bubble chat-bubble-${m.role}`}>
                  {m.role === "user" ? (
                    <>
                      {m.attachmentName ? <div className="chat-attachment"><Paperclip size={12} /> {m.attachmentName}</div> : null}
                      <div className="chat-plain">{m.display ?? m.content}</div>
                    </>
                  ) : m.error ? (
                    <div className="chat-error"><AlertTriangle size={14} /> Core hit an error responding. Try again.</div>
                  ) : m.pending && !m.content ? (
                    <div className="typing-indicator"><span /><span /><span /></div>
                  ) : (
                    <div className="md-body">{renderMarkdown(m.content)}</div>
                  )}
                </div>
                {m.role === "assistant" && !m.pending && !m.error ? (
                  <div className="chat-actions">
                    <button onClick={() => copyMessage(m.content)} title="Copy"><Copy size={13} /></button>
                    {idx === active.messages.length - 1 ? (
                      <button onClick={regenerate} title="Regenerate"><RefreshCw size={13} /></button>
                    ) : null}
                  </div>
                ) : null}
              </div>
            ))
          )}
        </div>

        <div className="ai-composer">
          {attachment ? (
            <div className="composer-attachment">
              <Paperclip size={12} /> {attachment.name}
              <button onClick={() => setAttachment(null)} aria-label="Remove attachment"><X size={12} /></button>
            </div>
          ) : null}
          <div className="composer-row">
            <button className="icon-btn" onClick={() => fileRef.current?.click()} title="Attach file" aria-label="Attach file"><Paperclip size={16} /></button>
            <input ref={fileRef} type="file" accept="image/*,.pdf,.txt,.md,.csv,.json" hidden onChange={handleFilePick} />
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
              placeholder="Message Core…"
              rows={1}
            />
            <button className="send-btn" onClick={() => send()} disabled={streaming || (!input.trim() && !attachment)} aria-label="Send message">
              {streaming ? <Loader2 size={16} className="spin-icon" /> : <Send size={16} />}
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
