"use client";

import { User } from "lucide-react";
import { NAV_ITEMS } from "@/lib/constants";

export default function BottomNav({ view, setView, profile, onAuthOpen }) {
  const items = profile ? NAV_ITEMS.concat([{ id: "settings", label: "Profile", icon: User }]) : NAV_ITEMS;
  return (
    <nav className="bottom-nav" aria-label="Primary">
      {items.map((item) => {
        const Icon = item.icon;
        const active = view === item.id;
        return (
          <button
            key={item.id}
            className={`bottom-nav-item ${active ? "bottom-nav-item-active" : ""}`}
            onClick={() => (item.id === "settings" && !profile ? onAuthOpen() : setView(item.id))}
          >
            <Icon size={19} />
            <span>{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
