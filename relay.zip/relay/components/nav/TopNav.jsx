"use client";

import { useState } from "react";
import { Zap, Sun, Moon, ChevronDown, LayoutDashboard, Settings as SettingsIcon, LogOut } from "lucide-react";
import { NAV_ITEMS } from "@/lib/constants";
import { Btn, Avatar } from "@/components/ui/Primitives";

export default function TopNav({ view, setView, profile, onAuthOpen, onLogout, theme, setTheme }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="top-nav">
      <div className="top-nav-inner">
        <button className="brand" onClick={() => setView("landing")} aria-label="Relay home">
          <span className="brand-mark"><Zap size={16} /></span>
          <span className="brand-name">Relay</span>
        </button>
        <nav className="top-nav-links" aria-label="Primary">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              className={`nav-link ${view === item.id ? "nav-link-active" : ""}`}
              onClick={() => setView(item.id)}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="top-nav-actions">
          <button className="icon-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="Toggle theme" title="Toggle theme">
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
          </button>
          {profile ? (
            <div className="profile-menu">
              <button className="profile-chip" onClick={() => setMenuOpen((v) => !v)}>
                <Avatar name={profile.name} color={profile.color} size={28} />
                <span className="profile-chip-name">{profile.name}</span>
                <ChevronDown size={14} />
              </button>
              {menuOpen ? (
                <div className="profile-dropdown" onMouseLeave={() => setMenuOpen(false)}>
                  <button onClick={() => { setView("dashboard"); setMenuOpen(false); }}><LayoutDashboard size={14} /> Dashboard</button>
                  <button onClick={() => { setView("settings"); setMenuOpen(false); }}><SettingsIcon size={14} /> Settings</button>
                  <button onClick={() => { onLogout(); setMenuOpen(false); }}><LogOut size={14} /> Log out</button>
                </div>
              ) : null}
            </div>
          ) : (
            <Btn size="sm" onClick={onAuthOpen}>Get started</Btn>
          )}
        </div>
      </div>
    </header>
  );
}
