"use client";

import { useState } from "react";
import { Modal, Btn } from "@/components/ui/Primitives";
import { AVATAR_COLORS } from "@/lib/constants";

export default function AuthModal({ open, onClose, onCreateProfile, existingProfile }) {
  const [tab, setTab] = useState("signup");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [color, setColor] = useState(AVATAR_COLORS[0]);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginMsg, setLoginMsg] = useState(null);

  function submitSignup(e) {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;
    onCreateProfile({ name: name.trim(), email: email.trim(), color, joinedAt: Date.now() });
  }

  function submitLogin(e) {
    e.preventDefault();
    if (existingProfile && existingProfile.email.toLowerCase() === loginEmail.trim().toLowerCase()) {
      onCreateProfile(existingProfile);
    } else {
      setLoginMsg("No matching profile found in this browser's storage — try Create profile instead.");
    }
  }

  return (
    <Modal open={open} onClose={onClose} width={420}>
      <div className="auth-tabs">
        <button className={tab === "signup" ? "auth-tab-active" : ""} onClick={() => setTab("signup")}>Create profile</button>
        <button className={tab === "login" ? "auth-tab-active" : ""} onClick={() => setTab("login")}>Log in</button>
        <button className={tab === "forgot" ? "auth-tab-active" : ""} onClick={() => setTab("forgot")}>Forgot password</button>
      </div>

      {tab === "signup" ? (
        <form onSubmit={submitSignup} className="auth-form">
          <label>Name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ava Chen" required /></label>
          <label>Email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ava@example.com" required /></label>
          <div className="color-row">
            {AVATAR_COLORS.map((c) => (
              <button type="button" key={c} className={`color-dot ${color === c ? "color-dot-active" : ""}`} style={{ background: c }} onClick={() => setColor(c)} aria-label={`Choose color ${c}`} />
            ))}
          </div>
          <p className="auth-note">This preview keeps your profile in this browser's local storage — no password required here. See the README for wiring up real authentication.</p>
          <Btn type="submit" className="auth-submit">Create profile</Btn>
        </form>
      ) : tab === "login" ? (
        <form onSubmit={submitLogin} className="auth-form">
          <label>Email<input type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="ava@example.com" required /></label>
          {loginMsg ? <p className="auth-note auth-note-warn">{loginMsg}</p> : null}
          <Btn type="submit" className="auth-submit">Log in</Btn>
        </form>
      ) : (
        <div className="auth-form">
          <p className="auth-note">
            This preview build doesn't use passwords, so there's nothing to reset — your profile is tied
            automatically to this browser. A production version would trigger a real reset email from a
            backend authentication service.
          </p>
        </div>
      )}
    </Modal>
  );
}
