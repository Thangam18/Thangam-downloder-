"use client";

import { useState } from "react";
import { Sun, Moon, LogOut, Trash2 } from "lucide-react";
import { Card, Btn, Avatar } from "@/components/ui/Primitives";
import { useToast } from "@/components/ui/Toast";
import { AVATAR_COLORS } from "@/lib/constants";

export default function Settings({ profile, updateProfile, theme, setTheme, onLogout, onResetData }) {
  const toast = useToast();
  const [name, setName] = useState(profile.name);
  const [color, setColor] = useState(profile.color);
  const [notif, setNotif] = useState(profile.notifications !== false);

  function save() {
    updateProfile({ ...profile, name: name.trim() || profile.name, color, notifications: notif });
    toast({ tone: "success", title: "Settings saved" });
  }

  return (
    <div className="view-shell">
      <div className="view-head"><h1>Settings</h1><p>Manage your profile and preferences.</p></div>

      <Card className="settings-card">
        <h3>Profile</h3>
        <div className="settings-row">
          <Avatar name={name} color={color} size={56} />
          <div className="color-row">
            {AVATAR_COLORS.map((c) => (
              <button key={c} className={`color-dot ${color === c ? "color-dot-active" : ""}`} style={{ background: c }} onClick={() => setColor(c)} aria-label={`Choose color ${c}`} />
            ))}
          </div>
        </div>
        <label>Display name<input value={name} onChange={(e) => setName(e.target.value)} /></label>
        <label>Email<input value={profile.email} disabled /></label>
      </Card>

      <Card className="settings-card">
        <h3>Preferences</h3>
        <div className="toggle-row">
          <div><span>Theme</span><p>Switch between dark and light interfaces.</p></div>
          <button className="icon-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")}>{theme === "dark" ? <Sun size={15} /> : <Moon size={15} />} {theme === "dark" ? "Light" : "Dark"}</button>
        </div>
        <div className="toggle-row">
          <div><span>Notifications</span><p>Get notified about completed downloads.</p></div>
          <button className={`switch ${notif ? "switch-on" : ""}`} onClick={() => setNotif((v) => !v)} aria-label="Toggle notifications"><span /></button>
        </div>
      </Card>

      <Card className="settings-card">
        <h3>Security</h3>
        <p className="auth-note">Password management isn't part of this preview build — see the FAQ on the homepage for why, and what a production version would use instead.</p>
      </Card>

      <div className="settings-actions">
        <Btn onClick={save}>Save changes</Btn>
        <Btn variant="secondary" icon={LogOut} onClick={onLogout}>Log out</Btn>
        <Btn variant="danger" icon={Trash2} onClick={onResetData}>Reset all data</Btn>
      </div>
    </div>
  );
}
