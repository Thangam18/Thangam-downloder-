"use client";

import { useState, useRef, useEffect } from "react";
import {
  Link2, Search, Loader2, Sparkles, AlertTriangle, Info, ArrowUpRight,
  Download, Video, Clock, CheckCircle2, User,
} from "lucide-react";
import { Btn, Badge, Card, Skeleton, ProgressBar, EmptyState } from "@/components/ui/Primitives";
import { useToast } from "@/components/ui/Toast";
import { detectUrl, formatBytes, uid } from "@/lib/helpers";
import { SAMPLE_ITEM } from "@/lib/constants";

export default function Downloader({ addHistory, profile, onAuthOpen }) {
  const toast = useToast();
  const [url, setUrl] = useState("");
  const [result, setResult] = useState(null); // detection result
  const [checking, setChecking] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState(null);
  const [job, setJob] = useState(null); // {progress, status}
  const [sampleMode, setSampleMode] = useState(false);
  const timerRef = useRef(null);

  useEffect(() => () => clearInterval(timerRef.current), []);

  function runDetect(e) {
    e && e.preventDefault();
    if (!url.trim()) {
      toast({ tone: "error", title: "Paste a URL first", body: "The input is empty right now." });
      return;
    }
    setChecking(true);
    setResult(null);
    setJob(null);
    setSelectedFormat(null);
    setSampleMode(false);
    setTimeout(() => {
      const detected = detectUrl(url);
      setResult(detected);
      setChecking(false);
    }, 650);
  }

  function startSample() {
    setSampleMode(true);
    setResult({ status: "sample" });
    setSelectedFormat(SAMPLE_ITEM.formats[0].id);
    setJob(null);
  }

  function beginDownload(formatId) {
    const fmt = SAMPLE_ITEM.formats.find((f) => f.id === formatId);
    setJob({ progress: 0, status: "running" });
    let p = 0;
    timerRef.current = setInterval(() => {
      p += Math.random() * 14 + 6;
      if (p >= 100) {
        p = 100;
        clearInterval(timerRef.current);
        setJob({ progress: 100, status: "done" });
        toast({ tone: "success", title: "Sample complete", body: "This shows the flow — paste a direct file link to download for real." });
        addHistory({ id: uid(), title: SAMPLE_ITEM.title, kind: SAMPLE_ITEM.kind, quality: fmt.label, size: fmt.size, date: Date.now(), sample: true });
        return;
      }
      setJob({ progress: p, status: "running" });
    }, 260);
  }

  function realDownload(finalUrl, filename) {
    try {
      const a = document.createElement("a");
      a.href = finalUrl;
      a.download = filename || "";
      a.target = "_blank";
      a.rel = "noopener";
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast({ tone: "success", title: "Download started", body: "Your browser is handling the transfer directly." });
      addHistory({ id: uid(), title: filename || finalUrl, kind: "file", quality: "Original", size: null, date: Date.now(), sample: false });
    } catch {
      toast({ tone: "error", title: "Couldn't start the download", body: "The browser blocked the request. Try opening the link directly." });
    }
  }

  return (
    <div className="view-shell">
      <div className="view-head">
        <h1>Downloader</h1>
        <p>Paste a URL to detect what it is. Direct file links download for real — everything else is handled honestly.</p>
      </div>

      <Card className="downloader-card">
        <form className="downloader-form" onSubmit={runDetect}>
          <div className="hero-input hero-input-flat">
            <Link2 size={16} className="hero-input-icon" />
            <input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/file.mp4"
              aria-label="Media URL"
            />
          </div>
          <Btn type="submit" icon={checking ? Loader2 : Search} disabled={checking} className={checking ? "spin-icon" : ""}>
            {checking ? "Detecting…" : "Detect"}
          </Btn>
        </form>
        <button className="sample-link" onClick={startSample}>
          <Sparkles size={13} /> Try a sample instead
        </button>
      </Card>

      {checking ? (
        <Card className="result-card">
          <Skeleton w="60%" h="18px" />
          <div style={{ height: 10 }} />
          <Skeleton w="40%" h="12px" />
          <div style={{ height: 16 }} />
          <Skeleton w="100%" h="44px" />
        </Card>
      ) : null}

      {!checking && result?.status === "invalid" ? (
        <Card className="result-card">
          <EmptyState
            icon={AlertTriangle}
            title="That doesn't look like a valid URL"
            body="Double-check it starts with http:// or https:// and try again."
          />
        </Card>
      ) : null}

      {!checking && result?.status === "unknown" ? (
        <Card className="result-card">
          <EmptyState
            icon={Info}
            title="Couldn't confirm this is downloadable media"
            body="Relay didn't recognize this as a supported platform or a direct media file. If it's a direct link to a video, audio or image file, double-check the file extension is in the URL."
          />
        </Card>
      ) : null}

      {!checking && result?.status === "matched" && result.platform.restricted ? (
        <Card className="result-card">
          <div className="result-head">
            <Badge tone="amber">{result.platform.label} detected</Badge>
          </div>
          <h3 className="result-title">Downloading isn't available for this platform</h3>
          <p className="result-body">
            {result.platform.label} doesn't permit downloading content outside its own official tools —
            offering it here would break their terms of service and, often, the uploader's copyright. Relay
            won't work around that.
          </p>
          <p className="result-suggestion">Try a direct file link, or an open-license source like the Internet Archive or Wikimedia Commons.</p>
        </Card>
      ) : null}

      {!checking && result?.status === "matched" && result.platform.kind === "open" && !result.platform.direct ? (
        <Card className="result-card">
          <div className="result-head"><Badge tone="mint">{result.platform.label} detected</Badge></div>
          <h3 className="result-title">Open-license source</h3>
          <p className="result-body">
            This source generally permits downloading, but pulling exact formats needs a backend media
            service this preview doesn't run. You can open the item directly instead.
          </p>
          <Btn icon={ArrowUpRight} onClick={() => window.open(result.url, "_blank", "noopener")}>Open source page</Btn>
        </Card>
      ) : null}

      {!checking && result?.status === "matched" && result.platform.direct ? (
        <Card className="result-card">
          <div className="result-head"><Badge tone="cyan">Direct file</Badge></div>
          <h3 className="result-title">{result.filename}</h3>
          <p className="result-body">This is a direct link to a media file — Relay can hand it straight to your browser.</p>
          <Btn icon={Download} onClick={() => realDownload(result.url, result.filename)}>Download file</Btn>
        </Card>
      ) : null}

      {sampleMode ? (
        <Card className="result-card">
          <div className="result-head"><Badge tone="violet">Sample preview</Badge></div>
          <h3 className="result-title">{SAMPLE_ITEM.title}</h3>
          <div className="result-meta">
            <span><Video size={13} /> {SAMPLE_ITEM.kind}</span>
            <span><Clock size={13} /> {SAMPLE_ITEM.duration}</span>
          </div>
          <div className="format-grid">
            {SAMPLE_ITEM.formats.map((f) => (
              <button
                key={f.id}
                className={`format-chip ${selectedFormat === f.id ? "format-chip-active" : ""}`}
                onClick={() => setSelectedFormat(f.id)}
                disabled={job?.status === "running"}
              >
                <span>{f.label}</span>
                <span className="format-chip-size">{formatBytes(f.size)}</span>
              </button>
            ))}
          </div>

          {job?.status === "running" ? (
            <div className="job-progress">
              <ProgressBar value={job.progress} />
              <div className="job-progress-row">
                <span>Preparing {SAMPLE_ITEM.formats.find((f) => f.id === selectedFormat)?.label}…</span>
                <span>{Math.round(job.progress)}%</span>
              </div>
            </div>
          ) : job?.status === "done" ? (
            <div className="job-success"><CheckCircle2 size={16} /> Sample complete — added to history{profile ? "" : " (sign in to keep it)"}.</div>
          ) : (
            <Btn icon={Download} onClick={() => beginDownload(selectedFormat)}>Simulate download</Btn>
          )}
        </Card>
      ) : null}

      {!profile ? (
        <button className="inline-auth-hint" onClick={onAuthOpen}>
          <User size={13} /> Set up a profile to keep your download history
        </button>
      ) : null}
    </div>
  );
}
